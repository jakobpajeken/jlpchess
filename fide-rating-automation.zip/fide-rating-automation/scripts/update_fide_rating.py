#!/usr/bin/env python3
"""
Fetches the current classical (standard) FIDE rating for Jakob Leon Pajeken
(FIDE ID 12942839) and writes it to rating.json in the repo root.

Meant to be run monthly by the accompanying GitHub Actions workflow
(.github/workflows/update-fide-rating.yml), but can also be run by hand:

    python scripts/update_fide_rating.py

Note: this parses FIDE's public profile page with a simple regex rather
than a documented API (FIDE doesn't offer one), so it's best-effort. If
FIDE changes their page layout, this script may need a small update —
look for where "logo_std.svg" appears on https://ratings.fide.com/profile/12942839
and adjust the parsing below to match.
"""

import datetime
import json
import re
import sys
import urllib.request

FIDE_ID = "12942839"
PROFILE_URL = f"https://ratings.fide.com/profile/{FIDE_ID}"
OUTPUT_PATH = "rating.json"


def fetch_html(url: str) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=20) as resp:
        return resp.read().decode("utf-8", errors="replace")


def extract_classical_rating(html: str) -> int:
    """Find the number shown next to the 'STANDARD' rating icon."""
    idx = html.find("logo_std.svg")
    if idx == -1:
        raise RuntimeError(
            "Could not find the standard-rating marker on the FIDE profile "
            "page — FIDE may have changed their page layout. This script "
            "needs a small update."
        )
    window = html[idx : idx + 400]
    text_only = re.sub(r"<[^>]+>", " ", window)
    match = re.search(r"\b(\d{3,4})\b", text_only)
    if not match:
        raise RuntimeError(
            "Found the standard-rating marker but no number near it — "
            "check the page layout."
        )
    return int(match.group(1))


def main() -> None:
    html = fetch_html(PROFILE_URL)
    rating = extract_classical_rating(html)

    now = datetime.date.today()
    data = {
        "classical": rating,
        "period": now.strftime("%Y-%b"),
        "source": PROFILE_URL,
        "updated": now.isoformat(),
    }

    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
        f.write("\n")

    print(f"Updated {OUTPUT_PATH} -> classical={rating}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:  # noqa: BLE001
        print(f"Failed to update FIDE rating: {exc}", file=sys.stderr)
        sys.exit(1)
